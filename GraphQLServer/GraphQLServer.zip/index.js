import express from 'express';
import bodyParser from 'body-parser';
import { graphiqlExpress, graphqlExpress } from 'graphql-server-express';
import {makeExecutableSchema} from 'graphql-tools';
import cors from 'cors';

//import schema from './schema/schema';

import {typeDefs} from './schema/typeDefs';
import {resolvers} from './schema/resolvers';

const schema = makeExecutableSchema({
    typeDefs,
    resolvers,
});

const app = express();
const port = 3000;

app.use(cors());

app.use('/graphiql', graphiqlExpress({
    endpointURL: '/graphql',
}));

app.use('/graphql', bodyParser.json(), graphqlExpress({schema}));


app.listen(port);
console.log('Running a GraphQL API server at localhost:' + port + '/graphql');
